/*****************************************************************************
* Copyright 2011 Nexteer Automotive, All Rights Reserved.
* Nexteer Confidential
*
* Module File Name  : Compiler_Cfg.h
* Module Description: This file contains a stub header for UTP and QAC 
*                     projects
* Product           : Gen II Plus EA3.0
* Author            : Lucas Wendling
*****************************************************************************/
/*---------------------------------------------------------------------------
* Version Control:
* Date Created:      Fri May  9 16:48:22 2003
* %version:          1 %
* %derived_by:       nzt9hv %
* %date_modified:    Wed May  8 15:40:34 2013 %
*---------------------------------------------------------------------------*/
#ifndef MEMMAP_H
#define MEMMAP_H

#endif  /* MEMMAP_H */

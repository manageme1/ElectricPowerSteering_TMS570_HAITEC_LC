/**********************************************************************
*
*       Header %name:   Sa_DigMSB.h %
*       Instance:               sag_EPS_1
*       Description:    
*       %created_by:    nzt9hv %
*       %date_created:  Fri Jul 26 10:39:18 2013 %
*
**********************************************************************/
#ifndef _SA_DIGMSB_H
#define _SA_DIGMSB_H


extern FUNC(void, SA_DIGMSB_CODE) DigMSB_Per1(void);

#endif
